# lws api test lwsac

Demonstrates how to use and performs selftests for lwsac

## build

```
 $ cmake . && make
```

## usage

Commandline option|Meaning
---|---
-d <loglevel>|Debug verbosity in decimal, eg, -d15

```
 $ ./lws-api-test-lwsac
[2018/10/09 09:14:17:4834] USER: LWS API selftest: lwsac
[2018/10/09 09:14:17:4835] USER: Completed: PASS
```

