# buffer
A buffer similar to the skbuff in the kernel, but more suitable for application.
