/* Copyright (c) 2011, NORDUnet A/S */
/* See LICENSE for licensing information. */

int radsecproxy_main(int argc, char **argv);

int main(int argc, char **argv)
{
  return radsecproxy_main(argc, argv);
}

/* Local Variables: */
/* c-file-style: "stroustrup" */
/* End: */
